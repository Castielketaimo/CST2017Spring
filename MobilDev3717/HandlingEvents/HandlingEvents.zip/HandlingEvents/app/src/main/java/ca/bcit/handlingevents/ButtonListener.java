package ca.bcit.handlingevents;

import android.view.View;
import android.widget.TextView;

/**
 * Created by A00127241 on 2017-09-25.
 */

public class ButtonListener implements View.OnClickListener {

    private TextView _tv;

    public ButtonListener(TextView tv) {
        _tv = tv;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.btn1:
                _tv.setText("Button 1 was clicked");
                break;
            case R.id.btn2:
                _tv.setText("Button 2 was clicked");
                break;
            case R.id.btn3:
                _tv.setText("Button 3 was clicked");
                break;
        }
    }

}
