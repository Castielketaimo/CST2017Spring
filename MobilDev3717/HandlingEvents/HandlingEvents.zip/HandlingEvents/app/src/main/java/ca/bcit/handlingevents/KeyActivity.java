package ca.bcit.handlingevents;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

public class KeyActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_key);

        EditText editTextName = (EditText) findViewById(R.id.editTextName);
        final TextView tvOutput = (TextView) findViewById(R.id.output);

        editTextName.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

                switch (i) {

                    case KeyEvent.KEYCODE_ENTER:
                        tvOutput.setText("The Enter key on a hard keyboard was pressed");
                        return true;
                    case KeyEvent.KEYCODE_SPACE:
                        tvOutput.setText("The Space key on a hard keyboard was pressed");
                        return true;
                    case KeyEvent.KEYCODE_PERIOD:
                        tvOutput.setText("The Period key on a hard keyboard was pressed");
                        return true;
                    case KeyEvent.KEYCODE_MINUS:
                        tvOutput.setText("The minus key on a hard keyboard was pressed");
                        return true;
                    case KeyEvent.KEYCODE_SEMICOLON:
                        tvOutput.setText("The semi colon key on on a digital pad was pressed");
                        return true;
                }
                return false;  // don't consume the event

            }
        });

    }
}
