package ca.bcit.handlingevents;

import android.app.Activity;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

public class CheckboxActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkbox);

        final TextView tvOutput = (TextView) findViewById(R.id.output);

        CheckBox chkMarried = (CheckBox) findViewById(R.id.chkMarried);
        chkMarried.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b)
                    tvOutput.setText("Married");
                else
                    tvOutput.setText("Not Married");
            }
        });

    }
}
