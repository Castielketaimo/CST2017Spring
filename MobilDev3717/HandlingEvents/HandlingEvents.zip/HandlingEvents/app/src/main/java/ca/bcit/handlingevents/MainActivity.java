package ca.bcit.handlingevents;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    protected void onCurrentClassClick(View v)
    {
        Intent i = new Intent(this, CurrentClassActivity.class);
        startActivity(i);
    }

    protected void onAnonymousClassClick(View v)
    {
        Intent i = new Intent(this, AnonymousClassActivity.class);
        startActivity(i);
    }

    protected void onSeparateClassClick(View v)
    {
        Intent i = new Intent(this, SeparateClassActivity.class);
        startActivity(i);
    }
    protected void onAnonymousInnerClassClick(View v)
    {
        Intent i = new Intent(this, AnonymousInnerClassActivity.class);
        startActivity(i);
    }

    protected void onCheckboxClick(View v)
    {
        Intent i = new Intent(this, CheckboxActivity.class);
        startActivity(i);
    }

    protected void onRadioClick(View v)
    {
        Intent i = new Intent(this, RadioButtonActivity.class);
        startActivity(i);
    }

    protected void onSeekBarClick(View v)
    {
        Intent i = new Intent(this, SeekBarActivity.class);
        startActivity(i);
    }

    protected void onSpinnerClick(View v)
    {
        Intent i = new Intent(this, SpinnerActivity.class);
        startActivity(i);
    }

    protected void onToastClick(View v)
    {
        Intent i = new Intent(this, ToastActivity.class);
        startActivity(i);
    }

    protected void onEditorActionsClick(View v)
    {
        Intent i = new Intent(this, EditorActivity.class);
        startActivity(i);
    }

    protected void onKeyEventsClick(View v)
    {
        Intent i = new Intent(this, KeyActivity.class);
        startActivity(i);
    }

}
