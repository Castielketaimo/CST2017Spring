package ca.bcit.handlingevents;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.widget.RadioGroup;
import android.widget.TextView;

public class RadioButtonActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_radio_button);

        final TextView tvOutput = (TextView) findViewById(R.id.output);

        RadioGroup rbtnGroup = (RadioGroup) findViewById(R.id.rbtnGroup);
        rbtnGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int i) {
                switch (i) {
                    case R.id.male:
                        tvOutput.setText("Male");
                        break;
                    case R.id.female:
                        tvOutput.setText("Female");
                        break;
                }
            }
        });

    }
}
