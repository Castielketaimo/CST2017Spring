package ca.bcit.handlingevents;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class SeparateClassActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_separate_class);


        TextView tvOutput = (TextView) findViewById(R.id.output);

        ButtonListener btnLstnr = new ButtonListener(tvOutput);

        Button btn1 = (Button) findViewById(R.id.btn1);
        btn1.setOnClickListener(btnLstnr);

        Button btn2 = (Button) findViewById(R.id.btn2);
        btn2.setOnClickListener(btnLstnr);

        Button btn3 = (Button) findViewById(R.id.btn3);
        btn3.setOnClickListener(btnLstnr);

    }
}
