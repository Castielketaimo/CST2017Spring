package ca.bcit.myplanet;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class CountryDetailsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_details);

        // get the country from the intent
        int countryIndex = (Integer) getIntent().getExtras().get("index");
        Country country = Country.northAmericaCountries[countryIndex];

        // Populate the country image
        ImageView photo = (ImageView) findViewById(R.id.photo);
        photo.setImageResource(country.getImageResourceId());
        photo.setContentDescription(country.getDescription());

        // Populate the country name
        TextView name = (TextView) findViewById(R.id.name);
        name.setText(country.getName());

        // populate the country description
        TextView desc = (TextView) findViewById(R.id.description);
        desc.setText(country.getDescription());

    }
}
