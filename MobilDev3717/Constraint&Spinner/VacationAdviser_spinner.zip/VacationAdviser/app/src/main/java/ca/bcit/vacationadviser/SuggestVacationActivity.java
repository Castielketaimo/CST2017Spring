package ca.bcit.vacationadviser;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

public class SuggestVacationActivity extends Activity {

    private ContinentExpert expert = new ContinentExpert();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggest_vacation);
    }

    public void onClickFindCountry(View v) {
        TextView country = (TextView) findViewById(R.id.country);
        Spinner continents = (Spinner) findViewById(R.id.continent);
       String continent = String.valueOf(continents.getSelectedItem());
        List<String> countryList = expert.getCountries(continent);
        StringBuilder formattedCountries = new StringBuilder();
        for (String item : countryList) {
            formattedCountries.append(item).append('\n');
        }
        country.setText(formattedCountries);
    }
}
