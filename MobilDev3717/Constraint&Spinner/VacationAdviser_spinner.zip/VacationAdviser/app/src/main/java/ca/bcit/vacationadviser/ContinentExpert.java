package ca.bcit.vacationadviser;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by A00127241 on 2017-09-13.
 */

public class ContinentExpert {
    List<String> getCountries(String continent) {
        List<String> countries = new ArrayList<>();
        switch (continent) {
            case "Africa":
                countries.add("Gambia");
                countries.add("Ghana");
                countries.add("Ethiopia");
                countries.add("Sudan");
                break;
            case "North America":
                countries.add("Mexico");
                countries.add("Canada");
                countries.add("USA");
                break;
            case "South America":
                countries.add("Brazil");
                countries.add("Ecuador");
                countries.add("Chile");
                countries.add("Peru");
                break;
            case "Asia":
                countries.add("China");
                countries.add("Japan");
                countries.add("Korea");
                countries.add("India");
                break;
            case "Australia":
                countries.add("Australia");
                break;
            case "Europe":
                countries.add("UK");
                countries.add("Germany");
                countries.add("France");
                countries.add("Sweeden");
                countries.add("Greece");
                countries.add("Portugal");
                countries.add("Spain");
                countries.add("Italy");
                break;
        }

        return  countries;
    }
}
