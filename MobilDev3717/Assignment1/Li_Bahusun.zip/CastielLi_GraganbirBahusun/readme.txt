Castiel Li
A00944987
castiel.andrew@gmail.com

I have completed all the requirment mentioned in the Assiganment pdf document
There's no any major challenges during the developement
You can test the app in anyway you want
Please note that the additional language I implemented is Japanese

Thank you :)