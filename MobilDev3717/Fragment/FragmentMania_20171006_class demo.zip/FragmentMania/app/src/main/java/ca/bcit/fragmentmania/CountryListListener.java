package ca.bcit.fragmentmania;

/**
 * Created by A00127241 on 2017-10-06.
 */

interface CountryListListener {
    void itemClicked(String countryName);
}
