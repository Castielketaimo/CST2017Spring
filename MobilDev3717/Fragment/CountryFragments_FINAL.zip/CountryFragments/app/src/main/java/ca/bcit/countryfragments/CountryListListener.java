package ca.bcit.countryfragments;

/**
 * Created by A00127241 on 2017-10-05.
 */

interface CountryListListener {
    void itemClicked(String countryName);
}
