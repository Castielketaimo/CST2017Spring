package ca.bcit.intentmessenger;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
public class CreateMessengerActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_messenger);
    }

    // call onSendMessage() when button is clicked
    public void onSendMessage(View view) {
        EditText messageView = (EditText) findViewById(R.id.message);
        String messageText = messageView.getText().toString();

        // Explicit intent
        Intent intent = new Intent(this, ReceiveMessageActivity.class);
        intent.putExtra("msg", messageText);
        startActivity(intent);

    }
}
