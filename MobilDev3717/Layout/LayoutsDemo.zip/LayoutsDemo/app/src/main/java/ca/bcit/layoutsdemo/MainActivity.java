package ca.bcit.layoutsdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    protected void onRelativeClick(View v) {
        Intent intent = new Intent(this, RelativeActivity.class);
        startActivity(intent);
    }

    protected void onLinearClick(View v) {
        Intent intent = new Intent(this, LinearActivity.class);
        startActivity(intent);
    }

    protected void onGridClick(View v) {
        Intent intent = new Intent(this, GridActivity.class);
        startActivity(intent);
    }

    protected void onTableClick(View v) {
        Intent intent = new Intent(this, TableActivity.class);
        startActivity(intent);
    }

    protected void onWebViewClick(View v) {
        Intent intent = new Intent(this, WebViewActivity.class);
        startActivity(intent);
    }

}
