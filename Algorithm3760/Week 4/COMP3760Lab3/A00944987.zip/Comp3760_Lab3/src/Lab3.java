
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;

/**
 * @author castiel
 *
 */
public class Lab3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			BufferedReader buffRead = new BufferedReader(new FileReader("Dict.txt"));
			String storeFile = buffRead.readLine();
			buffRead.close();
			String[] fileArray = storeFile.split(" ");
			long startTime = System.currentTimeMillis();
			int[] arrayofOccurents = new int[fileArray.length];
			for (int i = 0; i < fileArray.length; i++) {
				for (int j = i + 1; j < fileArray.length; j++) {
					if (Technique2(fileArray[i], fileArray[j])) {
						arrayofOccurents[i] = arrayofOccurents[i] + 1;
						arrayofOccurents[j] = arrayofOccurents[j] + 1;
					}
				}
			}
			long endTime = System.currentTimeMillis();
			int max = 0;
			int maxIndex = 0;
			for (int i = 0; i < arrayofOccurents.length; i++) {
				if (max < arrayofOccurents[i]) {
					maxIndex = i;
					max = arrayofOccurents[i];
				}
			}

			System.out.println("Tech3: " +  fileArray[maxIndex] + " with " + max + " appearances ");
			System.out.println("Took " + ((endTime - startTime) / 1000) + " seconds");

		} catch (Exception e) {
			System.out.println("error.");
		}

	}

	public static boolean Technique1(String word1, String word2) {
		if (word1.length() != word2.length()) {
			return false;
		}
		for (int i = 0; i < word1.length(); i++) {
			for (int j = 0; j < word2.length(); j++) {
				if (word1.charAt(i) == word2.charAt(j)) {
					word2 = word2.substring(0, j) + word2.substring(j+1);
					break;
				}
			}
		}
		if (word2.length() == 0) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean Technique2(String word1, String word2) {
		if (word1.length() != word2.length()) {
			return false;
		}
		char[] input1 = sort_char(word1);
		char[] input2 = sort_char(word2);
		return Arrays.equals(input1, input2);
	}

	public static boolean Technique3(String word1, String word2) {
		if (word1.length() != word2.length()) {
			return false;
		}
		int[] result = new int[128];
		
		for (int i = 0; i < word1.length(); i++) {
			result[(int) word1.charAt(i)]++;
			result[(int) word2.charAt(i)]--;
		}
		
		for (int i = 0; i < result.length; i++) {
			if (result[i] != 0) {
				return false;
			}
		}
		return true;
	}

	public static char[] sort_char(String word) {
		boolean resort = false;
		char[] wordInput = word.toCharArray();
		do {
			resort = false;
			for (int i = 0; i < wordInput.length - 1; i++) {
				if (wordInput[i] > wordInput[i + 1]) {
					wordInput = swap(wordInput, i, i + 1);
					resort = true;
				}
			}
		} while (resort);
		return wordInput;
	}

	public static char[] swap(char[] word, int indexA, int indexB) {
		char temp;
		temp = word[indexA];
		word[indexA] = word[indexB];
		word[indexB] = temp;
		return word;
	}

	public static char[] remove_char(char[] source, int index) {
		char[] result = new char[source.length - 1];
		int last_insert = 0;
		for (int i = 0; i < source.length - 1; i++) {
			if (i == index)
				i++;
			result[last_insert++] = source[i];
		}
		return result;
	}
}
