
public class Fib {

    public static void main(String[] args) {

        int n = 30;
        long start = System.nanoTime();
        int result = fib(n);
        long end = System.nanoTime();
        long microseconds = (end - start) / 1000;
        System.out.println("n: " + n + " Result: " + result + " in: " + microseconds + " microseconds");

    }

    public static int fib(int n) {

        if (n <= 1) {
            return n;
        } else {
            return (fib(n - 1) + fib(n - 2));
        }
    }

}
